package CGOL;
	import java.util.Scanner;

	/**
	 * Description : Implementing all rules of CGOL using Multithreading in JAVA and showing execution time.
	 * @author Sanjay Kumar
	 * @version 1.01   18-11-2019   Implementing all rules of CGOL using Multithreading in JAVA and showing execution time.
	 *
	 */
	public class Multi {
		
		public static void main(String[] args) {
			
	Scanner sc = new Scanner(System.in);

		   int grid[][]= new int[5][5];

		   int r=0, c=0;

		   for(r=0; r<5; r++) {

		      for(c=0;c<5;c++) {

		    System.out.println("Enter a value either 0 or 1 at grid["+r+"]["+c+"]");

		        

		    grid[r][c]=sc.nextInt();

		      }

		   }

		   System.out.println("Original Generation:");

		   for(r=0; r<5; r++) {

		      for(c=0;c<5;c++) {



		         System.out.print(""+ grid[r][c]);

		      }

		      System.out.println("");

		   }

		Console cr = new Console(grid);
		cr.start();

		}

	}


